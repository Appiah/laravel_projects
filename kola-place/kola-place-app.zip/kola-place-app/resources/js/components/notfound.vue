<template>
    <h1>Page not found</h1>
    <br>
    <router-link to="/">Back to homepage</router-link>
</template>