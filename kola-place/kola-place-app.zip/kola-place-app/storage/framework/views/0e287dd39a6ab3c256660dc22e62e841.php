<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products List</title>
</head>
<body>
    <div style="border; 3px solid black;">
        <h2>All Products</h2>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="background-color: gray; padding: 10px; margin: 10px;">
                <h3><?php echo e($product['id']); ?></h3>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/laravel_projects/kola-place/kola-place-app/resources/views/productslist.blade.php ENDPATH**/ ?>