<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kola Place App (Products)</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <div id="app_products_list">
           
    </div> 
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/laravel_projects/kola-place/kola-place-app/resources/views/productslistviavuejs.blade.php ENDPATH**/ ?>